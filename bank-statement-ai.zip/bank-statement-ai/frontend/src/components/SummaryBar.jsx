import { useState } from "react";
import {
  Alert,
  Box,
  Button,
  Chip,
  Dialog,
  DialogContent,
  DialogTitle,
  Paper,
  Stack,
  Typography,
} from "@mui/material";
import { formatAmount } from "../utils/review";

const METHOD_LABEL = { pdf_text: "PDF text", ocr: "OCR", mixed: "PDF text + OCR", none: "No text" };

export default function SummaryBar({ result, live, openCount }) {
  const [showRaw, setShowRaw] = useState(false);
  const balanceOk = live.mismatched.size === 0 && live.closingOk;
  return (
    <Paper sx={{ p: 2 }}>
      <Stack direction={{ xs: "column", md: "row" }} spacing={1} alignItems={{ md: "center" }} flexWrap="wrap" useFlexGap>
        <Typography variant="subtitle2" sx={{ mr: 1 }}>
          {result.file_name}
        </Typography>
        <Chip size="small" label={`${METHOD_LABEL[result.method]} · ${result.page_count} page(s)`} />
        {result.ocr_pages.length > 0 && <Chip size="small" label={`OCR pages: ${result.ocr_pages.join(", ")}`} />}
        {result.llm_used && <Chip size="small" color="secondary" label="Local LLM assisted" />}
        <Chip
          size="small"
          color={balanceOk ? "success" : "warning"}
          label={balanceOk ? "Running balance consistent" : `Balance issues: ${live.mismatched.size} row(s)${live.closingOk ? "" : " + closing"}`}
          data-testid="balance-chip"
        />
        <Chip
          size="small"
          color={openCount ? "warning" : "success"}
          variant={openCount ? "filled" : "outlined"}
          label={openCount ? `${openCount} item(s) to review` : "All flagged items reviewed"}
          data-testid="review-chip"
        />
        <Box sx={{ flexGrow: 1 }} />
        <Button size="small" onClick={() => setShowRaw(true)}>
          View extracted text
        </Button>
      </Stack>
      {live.computedClosing !== null && (
        <Typography variant="caption" color="text.secondary" component="div" sx={{ mt: 1 }}>
          Computed closing balance: {formatAmount(live.computedClosing)} · {result.confidence_note}
        </Typography>
      )}
      {result.warnings.map((w) => (
        <Alert key={w} severity="warning" sx={{ mt: 1, py: 0 }}>
          {w}
        </Alert>
      ))}
      <Dialog open={showRaw} onClose={() => setShowRaw(false)} maxWidth="md" fullWidth>
        <DialogTitle>Extracted text (account numbers redacted)</DialogTitle>
        <DialogContent>
          <Box component="pre" sx={{ fontSize: 12, whiteSpace: "pre-wrap", m: 0 }}>
            {result.raw_text || "(no text)"}
          </Box>
        </DialogContent>
      </Dialog>
    </Paper>
  );
}
